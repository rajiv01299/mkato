Changelog
=========

## 2.0.0 - 2019-07-13

### Added

* [Arguments] Arguments (eg `-help`) available via `php mkato.php -help`. 
* [Feature] Add multy attachment support.
* [Feature] Add swiftmailer as base for sending.
* [Feature] Add custom replacement.
* [System] Add user license to prevent ilegal user.
* [File] Encrypt important file.


### Fixed

* [Feature] Bug random function tag.
* [Feature] Bad date potition.

### Changed

* [Support] Only support for PHP 7.3 (Windows Xampp)
* [Support] Only support for PHP 7.2 (VPS)


--------
